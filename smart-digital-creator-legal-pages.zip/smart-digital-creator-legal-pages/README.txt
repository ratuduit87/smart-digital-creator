SMART DIGITAL CREATOR - halaman publik GitHub Pages

Isi:
- index.html (beranda/pengenalan penerbit)
- about.html (tentang penerbit dan produk)
- support.html (halaman bantuan)
- privacy.html (kebijakan privasi)
- terms.html (ketentuan layanan)
- style.css

PENTING:
1. Ini adalah draf awal, belum merupakan nasihat hukum dan perlu ditinjau penerbit sebelum dipublikasikan.
2. Belum ada URL publik sampai file diunggah ke repositori GitHub dan GitHub Pages diaktifkan.
3. Jangan mengirim API key, password, OTP, atau kredensial rahasia ke repositori.
4. Setelah Pages aktif, gunakan URL HTTPS yang benar-benar terbit untuk empat tautan pada listing plugin.
